﻿using RootAppCommon.Models;
using System.Windows.Forms;




namespace RootAppCommon
{
    public static class FormManager
    {
        #region "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 1"
        //static FormManager()
        //{
        //    MainForm = Application.OpenForms["MainForm"];
        //    _formInfos = new FormInfoMap();
        //}


        //public static readonly Form MainForm;


        //private static readonly FormInfoMap _formInfos;

        //public static FormInfo GetFormInfo(string name)
        //{
        //    if (_formInfos.ContainsKey(name))
        //        return _formInfos[name];
        //    else
        //    {
        //        FormInfo rfi = new FormInfo(name);
        //        _formInfos.Add(name, rfi);
        //        return rfi;
        //    }
        //}

        //public static void MakeFormInfo(string name, f)
        //{
        //    FormInfo rfi = GetFormInfo(name);
        //    if (rfi.RefFrom == null)
        //    {

        //    }
        //}

        //public static void Open(string name)
        //{
        //    FormInfo rfi = GetFormInfo(name);
        //    Form frm = rfi?.RefFrom;
        //    frm?.ShowDialog(MainForm);
        //}
        #endregion

    }

}
