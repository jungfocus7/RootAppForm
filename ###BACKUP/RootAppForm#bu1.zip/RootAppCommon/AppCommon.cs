﻿using System.Windows.Forms;




namespace RootAppCommon
{
    public static class AppCommon
    {
        static AppCommon()
        {
        }





    }
}
